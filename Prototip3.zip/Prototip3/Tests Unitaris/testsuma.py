def suma(a, b):
    """Retorna la suma de dos nombres."""
    return a + b
